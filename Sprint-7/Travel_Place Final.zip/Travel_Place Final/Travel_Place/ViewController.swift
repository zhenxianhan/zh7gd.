//
//  ViewController.swift
//  Travel_Place
//
//  Created by 韩镇先 on 5/13/20.
//  Copyright © 2020 Zhenxian Han. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController, GIDSignInDelegate {
    
    

    @IBOutlet weak var btnSignin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clicksignin(_ sender: UIButton) {
        
        GIDSignIn.sharedInstance()?.delegate = self
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.signIn()
        
        
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if error != nil {
            print(error.debugDescription)
        } else {
            
                let profileVC = self.storyboard?.instantiateViewController(withIdentifier: "NotesTableViewController") as? NotesTableViewController
                
                self.present(profileVC!, animated: true, completion: nil)
            }
        }
    }
    



